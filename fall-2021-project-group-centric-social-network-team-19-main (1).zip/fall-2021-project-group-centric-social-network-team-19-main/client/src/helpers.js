// some general helper functions

/* eslint-disable import/prefer-default-export */
export const arraysEqual = (a1, a2) => JSON.stringify(a1) === JSON.stringify(a2);
